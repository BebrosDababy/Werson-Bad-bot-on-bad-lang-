import asyncio 
from email import message
import imp
from multiprocessing.dummy import active_children
import discord
import random
from discord.ext import commands, tasks
from discord.utils import get
import os
from dotenv import load_dotenv
from youtube_dl import YoutubeDL
import json
from discord_components import DiscordComponents, ComponentsBot, Button, ButtonStyle, SelectOption, Select
import sqlite3 
from tabulate import tabulate
from dislash import InteractionClient, ActionRow, Button, ButtonStyle, SelectMenu, SelectOption, ContextMenuInteraction

load_dotenv()
Bot = commands.Bot(command_prefix = "+", intents = discord.Intents.all()) 
owner = [726008287463604224, 678623995930738712, 770596560773447682]
owners = 'ครг๒l๏๏๔#7228', 'ПиплплейГенералГавс#7402', '..............#4717'
Bot.remove_command('help')
intents = discord.Intents().all()
client = discord.Client(intents=intents)
inter = InteractionClient(Bot)
token = "OTcwMzg2MTQwNzUyMzg0MDgw.Ym7MhA.c-h8C8Bdu28KdZovhpec5ga_1Eg"

curseWord = ['+say']

@Bot.listen('on_message')
async def whatever_you_want_to_call_it(message):
    msg_content = message.content.lower()
    if any(word in msg_content for word in curseWord):
        await message.delete()

    else:
        return


@Bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        embed = discord.Embed(description = "Пожалуйста укажите **аргументы**.", color=0x6495ed)
        await ctx.channel.send(embed=embed),
    if isinstance(error, commands.MissingPermissions):
        embed = discord.Embed(description = "**Вы** не имеете права на эту команду.", color=0x6495ed)
        await ctx.channel.send(embed=embed) 

@Bot.event
async def on_ready():
    DiscordComponents(Bot)
    print("start")
    await Bot.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name="/info"))
 
@Bot.command()
async def cats(ctx): 
    possible_responses = [ 'https://c.tenor.com/ruxAFVJ03ogAAAAd/cat-berg-cat.gif', 'https://c.tenor.com/lASY8qJLPaAAAAAM/angry-black-cat-meme.gif', 'https://c.tenor.com/lolcvIC490YAAAAd/happy-smile.gif', 'https://c.tenor.com/58zyRKK0Zm8AAAAM/tayomaki-sakigifs.gif', 'https://c.tenor.com/e_cOg0wWyQUAAAAM/cat-finger.gif', 'https://c.tenor.com/ABeVmJ3y2WQAAAAd/cat-dancing-meme-dancing.gif'] 
    await ctx.send(f"{random.choice(possible_responses)}")

@Bot.command()
async def coin(ctx): 
    possible_responses = ['https://photo-monster.ru/forum/u_uploads/26789/16224/maxi/2017-01-09-10-12-1_44.jpg ', 'https://kvotka.ru/images/2017/01/23/RESKA2ff0c.jpg'] 
    await ctx.send(f"{random.choice(possible_responses)}")

@Bot.command()
async def dogs(ctx): 
    possible_responses = ['https://c.tenor.com/8sevXGqhohQAAAAi/doge-weird-doge.gif', 'https://c.tenor.com/OoLwPY0aSsEAAAAM/dogecoin-doge.gif', 'https://c.tenor.com/OupOmooPtnIAAAAM/doge-doge-coin.gif', 'https://c.tenor.com/KSGx7flxt4UAAAAM/heres-a-dogecoin-hers-some-doge.gif', 'https://c.tenor.com/m1TEptoKBjYAAAAM/dogecoin-notkdk3.gif'] 
    await ctx.send(f"{random.choice(possible_responses)}")

@Bot.command()
async def memes(ctx): 
    possible_responses = ['https://c.tenor.com/M3idAwyA32QAAAAd/peppa-pig-pig.gif', 'https://c.tenor.com/tInXY9TY0oMAAAAd/meme-dance.gif', 'https://c.tenor.com/GT5_1-5ftYkAAAAM/dance-fun.gif', 'https://c.tenor.com/44W--BLxv1cAAAAC/more-memes.gif', 'https://c.tenor.com/B9_W3Yqu-K8AAAAM/hog-meme.gif', 'https://c.tenor.com/hQvr-iA6_1cAAAAd/funny-memes.gif'] 
    await ctx.send(f"{random.choice(possible_responses)}")

@Bot.event
async def on_ready():
    print('The bot is logged in.')
    await Bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=f"на {len(Bot.guilds)} Серверов!"))

@Bot.command()
async def invite(ctx):
    embed = discord.Embed(description ="Пригласить бота [[**КЛИК**]](https://discord.com/api/oauth2/authorize?client_id=970386140752384080&permissions=8&scope=bot).", color=0x6495ed)
    await ctx.author.send(embed=embed)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def ban(ctx, user: discord.Member, *, reason=None):
    await user.ban(reason=reason)
    embed = discord.Embed(description =f"**{user}** Пользователь успешно заблокирован по причине **{reason}**", color=0x6495ed)
    await ctx.channel.send(embed=embed)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    await member.kick(reason=reason)
    embed = discord.Embed(description =f'Участник **{member}** был кикнут по причине **{reason}**.', color=0x6495ed)
    await ctx.channel.send(embed=embed)

@Bot.command() 
@commands.has_guild_permissions(administrator=True)
async def role(ctx, *, rolename=None): 
    if not rolename: await ctx.send("") 
    else: role = await ctx.guild.create_role(name=rolename, mentionable=True) 
    await ctx.author.add_roles(role) 
    embed = discord.Embed(description =f"Роль успешно созданна! **{role.mention}**!", color=0x6495ed)
    await ctx.channel.send(embed=embed)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def addrole(ctx, role:discord.Role):
  """Add a role to someone"""
  user = ctx.message.mentions[0]
  await user.add_roles(role)
  embed = discord.Embed(description = f"**{user.name}** Получил роль: **@{role.name}**", color=0x6495ed)
  await ctx.channel.send(embed=embed)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def temprole(ctx, member: discord.Member, role:discord.Role, time:int):
  """Add a role to someone"""
  user = ctx.message.mentions[0]
  await user.add_roles(role)
  embed = discord.Embed(description = f"**{member}** Получил временную роль: **@{role.name}** на **{time}** секунд(ы)", color=0x6495ed)
  await ctx.channel.send(embed=embed)
  await asyncio.sleep(time) 
  await member.remove_roles(role)

@Bot.command()
async def question(ctx, *, msg):
    items = [discord.Embed(description = f"Думаю, что да.:woozy_face: \n \n**Вопрос:** \n \n({msg})", color=0x6495ed),
             discord.Embed(description = f"Естественно!:tada: \n \n**Вопрос:** \n \n({msg})", color=0x6495ed),
             discord.Embed(description = f"Есть сомнения.:grimacing: \n \n**Вопрос:** \n \n({msg})", color=0x6495ed),
             discord.Embed(description = f"Хмм.. Не думаю.:face_with_monocle: \n \n**Вопрос:** \n \n({msg})", color=0x6495ed),
             discord.Embed(description = f"Я не знаю..:sob: \n \n**Вопрос:** \n \n({msg})", color=0x6495ed)]
    await ctx.send(embed=random.choice(items)) 

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def clear(ctx, amount):
    await ctx.channel.purge(limit=int(amount))
    embed = discord.Embed(description = f"**Вы** успешно удалили **{amount}** сообщений.", color=0x6495ed)
    msg = await ctx.channel.send(embed=embed)
    await asyncio.sleep(5)
    await msg.delete()

@Bot.command()
async def avatar(ctx, *,  avamember : discord.Member=None):
    userAvatarUrl = avamember.avatar_url
    await ctx.send(userAvatarUrl)

@Bot.command()
async def member(ctx,member:discord.Member = None, guild: discord.Guild = None):
    await ctx.message.delete()
    if member == None:
        emb = discord.Embed(title="Информация о пользователе", color=ctx.message.author.color)
        emb.add_field(name="Имя:", value=ctx.message.author.display_name,inline=False)
        emb.add_field(name="Айди пользователя:", value=ctx.message.author.id,inline=False)
        t = ctx.message.author.status
        if t == discord.Status.online:
            d = ":green_circle: В сети"

        t = ctx.message.author.status
        if t == discord.Status.offline:
            d = ":white_circle: Не в сети"

        t = ctx.message.author.status
        if t == discord.Status.idle:
            d = ":yellow_circle: Не активен"

        t = ctx.message.author.status
        if t == discord.Status.dnd:
            d = ":red_circle: Не беспокоить"

        emb.add_field(name="Активность:", value=d,inline=False)
        emb.add_field(name="Статус:", value=ctx.message.author.activity,inline=False)
        emb.add_field(name="Роль на сервере:", value=f"{ctx.message.author.top_role.mention}",inline=False)
        emb.add_field(name="Акаунт был создан:", value=ctx.message.author.created_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"),inline=False)
        emb.set_footer(text=f"Запросил {ctx.author} .", icon_url=ctx.author.avatar_url)
        await ctx.send(embed = emb)
    else:
        emb = discord.Embed(title="Информация о пользователе", color=member.color)
        emb.add_field(name="Имя:", value=member.display_name,inline=False)
        emb.add_field(name="Айди пользователя:", value=member.id,inline=False)
        t = member.status
        if t == discord.Status.online:
            d = ":green_circle: В сети"

        t = member.status
        if t == discord.Status.offline:
            d = ":white_circle: Не в сети"

        t = member.status
        if t == discord.Status.idle:
            d = ":yellow_circle: Не активен"

        t = member.status
        if t == discord.Status.dnd:
            d = ":red_circle: Не беспокоить"
        emb.add_field(name="Активность:", value=d,inline=False)
        emb.add_field(name="Статус:", value=member.activity,inline=False)
        emb.add_field(name="Роль на сервере:", value=f"{member.top_role.mention}",inline=False)
        emb.add_field(name="Акаунт был создан:", value=member.created_at.strftime("%a, %#d %B %Y, %I:%M %p UTC"),inline=False)
        emb.set_footer(text=f"Запросил {ctx.author} .", icon_url=ctx.author.avatar_url)
        await ctx.send(embed = emb)


@Bot.command()
async def secret(ctx):
    await ctx.message.delete()
    member = ctx.author 
    await member.send("aHR0cHM6Ly9tZWRpYS5kaXNjb3JkYXBwLm5ldC9hdHRhY2htZW50cy85NzA2MDc0OTAwMTIxNzY0NTQvOTcwOTc1MTg5MzA5NDU2Mzk0L3Vua25vd24ucG5n")
    await ctx.message.delete() # Deletes the users message


@Bot.command()
async def serverinfo(ctx):
        guild = ctx.guild
        embed = discord.Embed(title=f'{guild}', description="",
                          timestamp=ctx.message.created_at, color=discord.Color.red())
        embed.set_thumbnail(url=guild.icon_url)
        embed.add_field(name="Всего каналов:", value=len(guild.channels))
        embed.add_field(name="Кол-во ролей:", value=len(guild.roles))
        embed.add_field(name="Всего бустов:", value=guild.premium_subscription_count)
        embed.add_field(name="Кол-во Участников:", value=guild.member_count)
        embed.add_field(name="Дата создания:", value=guild.created_at)
        embed.set_footer(text=f"Запросил {ctx.author} .", icon_url=ctx.author.avatar_url)

        await ctx.send(embed=embed)



@Bot.command()
async def NSFW(ctx):
    row = ActionRow(
        Button(
            style=ButtonStyle.green,
            label="Да",
            custom_id="YES_NSFW"
        ),
        Button(
            style=ButtonStyle.red,
            label="Нет",
            custom_id="NO_NSFW" 
      )
)
    msg = await ctx.send("```Подтвердите действие для получения 18+ контента.```", components=[row])


    # Here timeout=60 means that the listener will
    # finish working after 60 seconds of inactivity
    on_click = msg.create_click_listener(timeout=5)

    @on_click.matching_id("YES_NSFW")
    async def on_test_button(inter):
        embed = discord.Embed(color=0x6495ed)
        embed.description = f"Вы подтвердили действие"
        await ctx.channel.send(embed=embed)
        await ctx.author.send("https://avatars.mds.yandex.net/i?id=bbb92e5bf241d62872df1410e431afe0-4055439-images-thumbs&n=13")
        await ctx.author.send("https://avatars.mds.yandex.net/i?id=2a00000179f2a5c490495ceec304063f50ab-4055835-images-thumbs&n=13")
        await ctx.author.send("https://analporngifs.com/content/2020/10/pau-no-rabo_001.gif")
        await ctx.author.send("https://s02.yapfiles.ru/files/1502044/straightpornpornosekretnyerazdelygifki778244.gif")
        await ctx.author.send("https://avatars.mds.yandex.net/i?id=6a179dc3d2d2908f7bd52758cebbbe89-5278644-images-thumbs&n=13")




    @on_click.matching_id("NO_NSFW")
    async def on_test_button(inter):
        await msg.delete()
        embed = discord.Embed(color=0x6495ed)
        embed.description = f"Вы отменили действие"
        await ctx.channel.send(embed=embed)

    @on_click.timeout
    async def on_timeout():
     await msg.delete()

@Bot.command()
async def info(ctx):
    embed=discord.Embed(title="Команды", description="(👨🏽‍💻) ***ВАЖНОЕ*** (👨🏽‍💻) \n \n**+time** - (:tada:) Запустить обратный отсчет (Время, сообщение). (:tada:) \n**+mute** - (📗) Временный мут, по секундам. (📗) \n**+tempban** - (📙) Временный бан, по секундам (📙) \n**+role** - (👁‍🗨) Создать роль. (👁‍🗨) \n**+addrole** - (🏧) Добавить роль участнику. (🏧) \n**+kick** - (💢) Кикнуть участника. (💢) \n**+temprole** - (:clock1: ) Выдать участнику временную роль. (:clock1:) \n**+clear** - (❌) Удалить ваше кол-во сообщений. (❌) \n**+ban** - (📕) Забанить участника. (📕) \n \n(🎇) ***ВЕСЕЛОЕ*** (🎇) \n \n**+coin** - (💵) Бросить монетку. (💵) \n**+question** (:face_with_monocle:) Задать вопрос Версону. (:face_with_monocle:) \n**+say** - (:pencil2:) Сказать что-то от имени бота. (:pencil2:) \n**+staff** - (:tropical_drink: ) Информация о команде разработчиков. (:tropical_drink: )  \n**+cats** - (🐱) Мемные котики. (🐱) \n**+dogs** - (🐶) Мемные собаки. (🐶) \n**+memes** - (🐵) Мемы. (🐵) \n**+invite** - (📬) Пригласить бота к себе на сервер. (📬)  \n**+U2VjcmV0** - (📌) ????? (📌) \n**+serverinfo** - (❓) Просмотреть информацию о сервере. (❓) \n**+NSFW** - (⚠️) Получить 18+ контент в лс. (⚠️) \n **+member** (👂🏽) Узнать информацию о участнике. (👂🏽) \n **+avatar** - (👦🏼) Получить аватарку участника. (👦🏼)", color=0x6495ed)
    embed.set_footer(text=f"Запросил {ctx.author} .", icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

@Bot.command()
async def staff(ctx):
    embed=discord.Embed(title="Команда разработчиков", description="(📕) ***РАЗРАБОТЧИКИ*** (📕) \n(📕) **Главный Разработчик.** (📕) - <@726008287463604224> \n \n (📒) ***ДИЗАЙНЕРЫ*** (📒) \n  (📒) **Главный дизайнер** (📒) - <@678623995930738712> \n \n(📙) ***ТЕСТЕРЫ*** (📙) \n(📙) **Главный Тестер** (📙) - <@802570589255761920> \n \n(📗) ***ИДЕОЛОГИ*** (📗) \n(📗) **Главный Идеолог** (📗) - <@872230047665238048>" , color=0x6495ed)
    embed.set_footer(text=f"Запросил {ctx.author} .", icon_url=ctx.author.avatar_url)
    await ctx.send(embed=embed)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def tempban(ctx, user:discord.User, duration: int, *, reason):
    await ctx.guild.ban(user)
    embed = discord.Embed(description = f"**{user}** был забанен на **{duration}** секунд(ы), по причине **{reason}**", color=0x6495ed)
    await ctx.channel.send(embed=embed)
    await asyncio.sleep(duration)
    await ctx.guild.unban(user)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def unban(ctx, user):
    await ctx.guild.unban(user)
    embed = discord.Embed(description = f"**{user}** был разбанен.", color=0x6495ed)
    await ctx.channel.send(embed=embed)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def mute( ctx, member: discord.Member, time: int, *, reason):

    muted_role = discord.utils.get(ctx.message.guild.roles, name="Muted")
    await member.add_roles(muted_role)
     
    embed = discord.Embed(description = f"**{member}** был замучен на **{time}** секунд(ы), по причине **{reason}**", color=0x6495ed)
    await ctx.channel.send(embed=embed)
    await asyncio.sleep(time)
    await member.remove_roles(muted_role)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def say(ctx, *, msg ):
    embed = discord.Embed(description = f"{msg}", color=0x6495ed)
    await ctx.channel.send(embed=embed)

@Bot.command()
@commands.is_owner()
async def servers(ctx):
    await ctx.message.delete()
    msg1 = embed = discord.Embed(description = f"**Я** нахожусь на **{len(Bot.guilds)}** серверах.", color=0x6495ed)
    await ctx.channel.send(embed=embed)
    await asyncio.sleep(2)
    for guild in Bot.guilds:
        embed = discord.Embed(description = f"**Название сервера:** \n{guild.name} \n \n **Айди сервера:** \n {guild.id}", color=0x6495ed)
        msg =  await ctx.channel.send(embed=embed)
        await asyncio.sleep(3)
        await msg.delete()

@Bot.command()
@commands.is_owner()
async def serverinvite(ctx, server_id: int):
    await ctx.message.delete()
    guild = Bot.get_guild(server_id)
    invite = await guild.text_channels[0].create_invite(max_age=1, max_uses=1, temporary=False)
    await ctx.send(f"https://discord.gg/{invite.code}")
    embed = discord.Embed(description = f"Приглашение **успешно** сгенерировано.", color=0x6495ed)
    await ctx.channel.send(embed=embed)

@Bot.command(name="leave")
@commands.is_owner()
async def __leave_from_server(ctx, server: discord.Guild = None):
    await ctx.message.delete()
    if server:
        await server.leave()
        embed = discord.Embed(description = f"Я успешно вышел с сервера **{server}**.", color=0x6495ed)
        await ctx.send(embed=embed)
    else:
        embed = discord.Embed(description = f"Пожалуйста укажите **аргументы**.", color=0x6495ed)
        await ctx.send(embed=embed)

@Bot.command()
@commands.has_guild_permissions(administrator=True)
async def time(ctx, time: int, *, message):
    embed = discord.Embed(description = f"Обратный отсчет начался, до завершения **{time}** секунд(ы)", color=0x6495ed)
    await ctx.channel.send(embed=embed)
    def check(message):
        return message.channel == ctx.channel and message.author == ctx.author and message.content.lower() == "cancel"
    try:
        m = await Bot.wait_for("message", check=check, timeout=time)
        await ctx.send("Обратный отсчет отменен")
    except asyncio.TimeoutError:
        embed = discord.Embed(description = f"Обратный завершен. Он длился **{time}** секунд(ы) Сообщение:  **{message}**", color=0x6495ed)
        await ctx.channel.send(embed=embed)

Bot.run(token)